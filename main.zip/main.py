import App

app1 = App.App()
app1.loop()